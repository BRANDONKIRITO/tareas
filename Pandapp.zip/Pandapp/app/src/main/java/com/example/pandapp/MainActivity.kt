package com.example.pandapp

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import android.util.Patterns

class MainActivity : AppCompatActivity() {

    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var checkBoxTerms: CheckBox
    private lateinit var loginButton: Button
    private lateinit var detailsButton: Button
    private lateinit var facebookButton: LinearLayout
    private lateinit var googleButton: LinearLayout
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        emailEditText = findViewById(R.id.Email)
        passwordEditText = findViewById(R.id.password)
        checkBoxTerms = findViewById(R.id.cbAcept)
        loginButton = findViewById(R.id.tvlogin)
        detailsButton = findViewById(R.id.btnDetalles)
        facebookButton = findViewById(R.id.BotonF)
        googleButton = findViewById(R.id.BotonG)
        dbHelper = DatabaseHelper(this)

        loginButton.setOnClickListener {
            validarCampos()
        }

        detailsButton.setOnClickListener {
            val intent = Intent(this, DetailsActivity::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in, R.anim.slide_out) // Agregamos la animación
        }

        facebookButton.setOnClickListener {
            abrirEnlace("https://www.facebook.com")
        }

        googleButton.setOnClickListener {
            abrirEnlace("https://accounts.google.com")
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                mostrarConfirmacionSalida()
            }
        })
    }

    private fun esCorreoValido(correo: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(correo).matches()
    }

    private fun enviarCorreo(emailDestino: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "message/rfc822"
            putExtra(Intent.EXTRA_EMAIL, arrayOf(emailDestino))
            putExtra(Intent.EXTRA_SUBJECT, "Registro exitoso")
            putExtra(Intent.EXTRA_TEXT, "Gracias por registrarte en nuestra aplicación.")
        }

        try {
            startActivity(Intent.createChooser(intent, "Enviar correo..."))
        } catch (ex: android.content.ActivityNotFoundException) {
            Toast.makeText(this, "No tienes aplicaciones de correo instaladas.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun validarCampos() {
        val email = emailEditText.text.toString()
        val password = passwordEditText.text.toString()
        val aceptaTerminos = checkBoxTerms.isChecked

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
        } else if (!esCorreoValido(email)) {
            Toast.makeText(this, "Correo electrónico no válido", Toast.LENGTH_SHORT).show()
        } else if (!aceptaTerminos) {
            Toast.makeText(this, "Debes aceptar los términos", Toast.LENGTH_SHORT).show()
        } else {
            enviarCorreo(email)
            val usuarioExiste = dbHelper.verificarUsuario(email, password)
            if (usuarioExiste) {
                Toast.makeText(this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, HomeActivity::class.java)
                startActivity(intent)
                overridePendingTransition(R.anim.slide_in, R.anim.slide_out) // Agregamos la animación
                finish()
            } else {
                val insertado = dbHelper.insertarUsuario(email, password)
                if (insertado) {
                    Toast.makeText(this, "Usuario registrado correctamente", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, HomeActivity::class.java)
                    startActivity(intent)
                    overridePendingTransition(R.anim.slide_in, R.anim.slide_out) // Agregamos la animación
                    finish()
                } else {
                    Toast.makeText(this, "Error al registrar usuario", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun abrirEnlace(url: String) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(url)
        startActivity(intent)
    }

    private fun mostrarMensaje(titulo: String, mensaje: String) {
        AlertDialog.Builder(this)
            .setTitle(titulo)
            .setMessage(mensaje)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun mostrarConfirmacionSalida() {
        AlertDialog.Builder(this)
            .setTitle("Confirmación")
            .setMessage("¿Seguro que quieres salir sin seleccionar un producto?")
            .setPositiveButton("Sí") { _, _ -> finish() }
            .setNegativeButton("No", null)
            .show()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out) // Animación al volver atrás
    }
}
