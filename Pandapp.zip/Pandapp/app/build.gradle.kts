plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    id("com.google.gms.google-services") version "4.3.15" apply false
}

android {
    namespace = "com.example.pandapp"
    compileSdk = 34  // 🔧 Bajado a 34 para mayor estabilidad

    defaultConfig {
        applicationId = "com.example.pandapp"
        minSdk = 24
        targetSdk = 34  // 🔧 Bajado a 34
        versionCode = 1
        versionName = "1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17  // 🔧 Subido a Java 17 (recomendado)
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"  // 🔧 Subido a Java 17
    }

    buildFeatures {
        compose = true
    }

    packagingOptions {
        resources {
            excludes.add("META-INF/NOTICE.md")
            excludes.add("META-INF/LICENSE.md")
        }
    }
}

dependencies {
    // 📌 Solo una versión de Material Components
    implementation("com.google.android.material:material:1.11.0")

    // 📌 Librerías para enviar correos (verifica si realmente las necesitas)
    implementation("com.sun.mail:android-mail:1.6.7")
    implementation("com.sun.mail:android-activation:1.6.7")

    // 📌 Firebase BOM (maneja versiones automáticamente)
    implementation(platform("com.google.firebase:firebase-bom:33.10.0"))

    // 📌 Core de AndroidX
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.core:core-ktx:1.9.0")

    // 📌 Jetpack Compose
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)

    // 📌 Debugging y testing
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)


    implementation ("com.airbnb.android:lottie:6.0.0")
}
